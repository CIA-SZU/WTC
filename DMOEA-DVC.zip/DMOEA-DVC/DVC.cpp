#include "common\global.h"
#include "DVC\DVCfunc.h"
#include <time.h>
void execute();

void main()
{
	// The settings of algorithm
	int pop[] = { 100,  100,  100,  105,  105,  100,  100,  100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100};     // population size
	int obj[] = { 2,    2,    2,    3,    3,    2,    2,    2,   2,   2,    2,   2,   2,   2,   2,   2,   2,   2,   2,	2 };       // number of objective functions
	int var[] = { 11,   11,   11,   11,   11,   11,   11,   11,  11,  11,  11,  11,  11,  11,  11,  11,  11,  11,  11,	11};       // dimensionality of search space
	char *ins[] = {"FDA1","FDA2","FDA3","FDA4","FDA5","dMOP1","dMOP2","dMOP3","DIMP1","DIMP2","JY1","JY2","JY3","JY4","JY5","JY6", "JY7", "JY8", "JY9","ZJZ1"};
	
	cout << "DMOEA-DVC	";
	int i;
	i=0;
	taut=5;
	max_run = 5;
	//for(taut = 5; taut <= 20; taut=taut*2)
	{
		max_gen=50;
		//max_gen = T0+10*nt*taut;
		//for (i=0; i<=18; i++)
		{
			cout << "nt:" << nt << "	taut:" << taut << "	problem:" << ins[i] << endl;
			nvar = var[i];                  //���߱�������
			nobj = obj[i];                  //Ŀ�꺯������
			setbound(i);                    //���߱���������		
			pops = pop[i];                  //��Ⱥ��С
			strcpy(strTestInstance,ins[i]); //��������
			execute();
			cout << ins[i] << " is finished" << endl;
		}
	}
}

void execute()
{
	int run;
	for(run=1; run<=max_run; run++) 
	{
		CDVC DVC;
		DVC.execute(run);
	}
}