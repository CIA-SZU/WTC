#ifndef __CDVCCLASS_H_
#define __CDVCCLASS_H_

#include "..\common\global.h"
#include "..\common\recombination.h"
#include "..\common\common.h"
#include "DVCclass.h"
#include <string.h>
#include "..\common\kalman.h"

class CDVC
{
public:
	CDVC();
	virtual ~CDVC();

	void init_population();                              // initialize the population
	void update_population(CDVCInd &indiv);              // update population 
	void update_achive(CDVCInd &ind);                    // update archive
	void evolution();                                    // �Ӵ����ɺ͸ı���Ӧ
	int  tour_selection();								 // Tournament selection of parents
	void environmentselection();
	void fill_union(CDVCInd &ind);
	vector  <int> truncation(vector <CDVCInd> pop, vector <int> v1, int m);
	vector<vector <int> > preservation(vector <CDVCInd> &pop, int m);

	void introduce_dynamics(int g);
	bool detect_change(int n);
	void react_change();
	void para_init();

	void execute(int run);

	vector <CFIN>      population;
	vector <CDVCInd>   ps;
	vector <CDVCInd>   offspring;
	vector <int>       array;
	CDVCInd           *ind_arr;

	vector <CDVCInd>   Archive;
	int                nondomsize;

	vector<double>  C0, C1;                   // Store centriod of POS in the past two POSs

	void operator=(const CDVC &moea);

	vector < KalmanFilter > myFilter;
	double ttest[50];
	double LastDV[50];
	double CurrentDV[50];

	void StaticClassification();
};

CDVC::CDVC()
{

	ind_arr = new CDVCInd[nobj];
	myFilter.resize(nvar);
	// initialize ideal point
	for(int n=0; n<nobj; n++)
	{
		idealpoint.push_back(1.0e+30);
		nadirpoint.push_back(-1.0e+30);
		intercept.push_back(-1.0e+30);
		ind_arr[n].rnd_init();
		ind_arr[n].obj_eval();
	}
}

CDVC::~CDVC()
{
	idealpoint.clear();
	nadirpoint.clear();
	intercept.clear();
	delete [] ind_arr;
}

void CDVC::init_population()
{
	int i;
	for (i = 0; i < pops; i++)
	{	
		CFIN sub;
		population.push_back(sub);
		population[i].indiv.rnd_init();
		population[i].indiv.obj_eval();
	}	
}

void CDVC::operator=(const CDVC &alg)
{
	population = alg.population;
	ps         = alg.ps;
	ind_arr    = alg.ind_arr;
	offspring  = alg.offspring;
}

void CDVC::update_population(CDVCInd &indiv)
{
	// indiv: child solution
	int k=0, incomp=0;
	double max = -1.0e+30;
	indiv.ncount = 0;
	for (int i = 0; i < population.size(); i++)
	{
		// 2: ��������һ��
		// 1: indiv֧����Ⱥ�еĸ���;
		// 0: �����֧��;
		//-1: ��Ⱥ�еĸ���֧��indiv;
		int dominate = population[i].indiv.compare(indiv);
		switch (dominate)
		{
			case 2: return;
				break;
			case 1: population[i].indiv.ncount++; 
				break;
			case 0: incomp++;
				break;
			case -1: indiv.ncount++;
				break;
			default: break;
		}
		//ѡ����Ⱥ����Ӧ�����ĸ���
		if (max < population[i].indiv.ncount)
		{
			k = i;
			max = population[i].indiv.ncount;
		}
	}

	// do nothing if indiv is worse than any ind in pop
	if (max < indiv.ncount) return;

	// replace a random ind with indiv if indiv and pop are nondominated
	if (incomp == population.size())
	{
		k = int(population.size()*rnd_uni(&rnd_uni_init));
	}

	//��indiv����Ⱥ�����и��嶼����֧�䣬�����ѡһ�����屻indivȡ��
	//��indiv�����ĸ������Ӧֵ�ã���ȡ���ø���
	indiv.fitness = 1.0*indiv.ncount;
	population[k].indiv = indiv;

	// update archive
	if (indiv.ncount < 1) update_achive(indiv);

}

// ���浵��Ⱥ�б�ind֧��ĸ��嶼����������ind����浵��
void CDVC::update_achive(CDVCInd &ind)
{
	int size = Archive.size();
	for (int i = 0; i < size; i++)
	{
		int dominate = Archive[i].compare(ind);
		if (dominate == 2 || dominate == -1) break;
		if (dominate = 1)
		{ 
			Archive.erase(Archive.begin() + i); 
			size--;
		}
	}
	Archive.push_back(ind);
}

int  CDVC::tour_selection()
{
	int p1 = int(rnd_uni(&rnd_uni_init)*population.size());
	int p2 = int(rnd_uni(&rnd_uni_init)*population.size());

	if (population[p1].indiv.ncount<population[p2].indiv.ncount)
		return p1;
	else
		return p2;
}

void CDVC::environmentselection()
{
	// merge of current population and archive population
	// duplicate individuals are removed.
	int i;
	for (i=0; i<population.size(); i++)
		fill_union(population[i].indiv);

	// identification of nondominated solutions
	Archive.clear();
	vector<vector<int> > Index;
	Index=preservation(offspring, population.size());
	//��Index[0]����eliteIn��
	vector< int> eliteIn(Index[0]);
	//��Index[1]����nondomIn��
	vector< int> nondomIn(Index[1]);
	nondomsize=nondomIn.size();

	//����֧���������С��population��Ⱥ��С
	if (nondomsize<population.size())
	{
		//����֧��������η���Archive��
		for (int i=0; i<nondomsize; i++)
			Archive.push_back(offspring[nondomIn[i]]);
		//��population�е����и������Ϊ�����Ӵ������еľ�Ӣ����
		for (i=0; i<population.size(); i++)
			population[i].indiv=offspring[eliteIn[i]];
	}

	//����֧�������������population��Ⱥ��С
	if (nondomsize==population.size())
	{
		for (int i=0; i<population.size(); i++)
		{
			//��population�е����и������Ϊ��֧�����
			population[i].indiv=offspring[nondomIn[i]];
			//����֧��������η���Archive��
			Archive.push_back(offspring[nondomIn[i]]);
		}
	}

	//����֧�������������population��Ⱥ��С
	if (nondomsize>population.size())
	{
		// Reduce the risk of too many extreme solutions.
		vector <int> trunIn;
		//���ظ������ŵ�trunIn
		//trunIn[]���population.size()����֧���������
		trunIn = truncation(offspring, nondomIn, population.size());
		for (int i=0; i<population.size(); i++)
		{
			population[i].indiv=offspring[trunIn[i]];
			Archive.push_back(offspring[trunIn[i]]);
		}
	}

	for (i=0; i<population.size(); i++)
		offspring[i]=population[i].indiv;
	while (offspring.size()>population.size()) offspring.pop_back();

}

//����������Ⱥ��һ���Ƿ�֧�����ļ��ϣ�һ���Ǿ�Ӣ����
vector  <vector <int> > CDVC::preservation(vector <CDVCInd> &pop, int m)
{
	double *fit=new double[pop.size()];
	int* idx2=new int[pop.size()];

	vector <int> accept, reject;

	int id=0;

	for (int i = 0; i < pop.size(); i++)
	{
		pop[i].ncount = 0;
		for (int j = 0; j < pop.size(); j++)
		{
			if (i != j)
			{
				if (pop[i].compare(pop[j]) == 1)  pop[i].ncount++;
			}
		}
	}

	// nondominance identification
	vector <int> nondomindex;
	
	//��pop��Ⱥ�еķ�֧��������ŷ���nondomindex��
	//fit[]���popÿ���������Ӧֵ
	//idx2[]���popÿ����������
	for(i=0; i<pop.size(); i++)
	{
		if (pop[i].ncount==0) 
		{
			nondomindex.push_back(i);
		}
		pop[i].fitness=1.0*(pop[i].ncount);
		fit[i]=pop[i].fitness;
		idx2[i]=i;
	}

	//fit[]��С��������
	minquicksort(fit, idx2, 0, pop.size());

	for (i = 0; i < pop.size(); i++)
	{
		if (i < m) accept.push_back(idx2[i]);	
	}

	delete [] fit;
	delete [] idx2;

	vector <vector <int> > twovector;
	//twovector����������Ⱥ
	//twovector(0)���游�Ӳ����еľ�Ӣ����
	//twovector(1)���游�Ӳ����еķ�֧�����
	twovector.push_back(accept);
	twovector.push_back(nondomindex);

	return twovector;
}


vector <int> CDVC::truncation(vector <CDVCInd> pop, vector <int> v1, int m)
{
	int size = v1.size();
	int **distIndex = new int*[size];
	double **distSort = new double*[size];

	vector <int> record(size,1);
	vector <int> accept;

	double INF = 1.0E+30;
	for (int i = 0; i < size; i++)
	{
		distIndex[i] = new int[size];
		distSort[i] = new double[size];
		for (int j = 0; j < i; j++)
		{
			distIndex[i][j] = j;
			distSort[i][j] = dist_vector(pop[v1[i]].y_obj, pop[v1[j]].y_obj);
			distIndex[j][i] = i;
			distSort[j][i] = distSort[i][j];
		}
		distIndex[i][i] = i;
		distSort[i][i] = INF;
	}

	for (i = 0; i < size; i++)
		minquicksort(distSort[i], distIndex[i], 0, size);
		
	int cursize = size, mark, count;
	double min;
	bool same;
	while (cursize>m)
	{
		min = INF;
		for (int i = 0; i < size; i++)
			if (record[i])
			{
				if (min>distSort[i][0])
				{
					min = distSort[i][0];
					mark = i;
				}
				else
				{
					if (min == distSort[i][0])
					{
						same = (pop[v1[i]].y_obj==pop[v1[mark]].y_obj);
						if (same == false)
						{
							count = 0;
							while (distSort[mark][count] == distSort[i][count] && count < cursize - 1) count++;
							if (distSort[mark][count] > distSort[i][count]) mark = i;
						}
					}
				}
			}
		record[mark] = 0;
		for (i = 0; i < size; i++)
		{
			int flag = 0;
			if (record[i])
			{
				for (int j = 0; j < cursize; j++)
				{
					if (distIndex[i][j] == mark) flag = 1;
					if (flag)
						if (j < cursize - 1)
						{
							distSort[i][j] = distSort[i][j + 1];
							distIndex[i][j] = distIndex[i][j + 1];
						}
				}
				distSort[i][cursize - 1] = INF;
				distIndex[i][cursize - 1] = mark;
			}
		}
		cursize--;
	}
	for (i = 0; i < size; i++)
	{
		if (record[i]) accept.push_back(v1[i]);
		delete[] distSort[i];
		delete[] distIndex[i];
	}
	delete[] distSort;
	delete[] distIndex;

	return accept;

}

//������ind����offspring�У���ind�ŵ����
void CDVC::fill_union(CDVCInd &ind)
{
	bool flag = true;
	int  size = offspring.size();
	for(int i=0; i<size; i++){
		if(ind==offspring[i]){
			flag = false;
			break;
		}
	}
	if(flag) offspring.push_back(ind);
}

void CDVC::evolution()
{
	int *perm = new int[pops];
	random_permutation(perm, pops);

	int i, n;
	bool changeIsTrue = false, reactIsTrue=false;

	for(i=0; i<pops; i++)
	{
		n = perm[i];	
		
		if (!changeIsTrue)
			changeIsTrue = detect_change(n);
		if ((!reactIsTrue)&&changeIsTrue)
		{
			react_change();
			reactIsTrue=true;
		}
		
		// select the indexes of mating parents
		// 50%��P��ѡһ������A��ѡһ�������߽��䣻50%��P��ѡ��������
		// �������Ӵ�Ϊchild1
		vector<int> p;
		CDVCInd child1, child2;
		double pe = 1.0*(pops-nondomsize)/pops;
		int dominate;
		if (rnd_uni(&rnd_uni_init) < 0.5)
		{
			int p1, p2, p3;
			p1= (int)(Archive.size())*rnd_uni(&rnd_uni_init);
			while (1)
			{
				p2 = tour_selection();  
				dominate = population[p2].indiv.compare(Archive[p1]);
				if (dominate!=2)
					break; 
			}
			while (1)
			{
				p3 = tour_selection();
				dominate = Archive[p1].compare(population[p3].indiv);
				if (dominate != 2 && p3 != p2)
					break;
			}
			SBXDE(Archive[p1], population[p2].indiv, population[p3].indiv,population[p2].indiv,Archive[p1],child1,child2,child1);
		}
		else
		{
			int p1, p2, p3;
			p1 = tour_selection();
			while (1){ p2 = tour_selection();  	if (p2 != p1) break; }
			while (1){ p3 = tour_selection();  	if (p3 != p1 && p3 != p2) break; }
			SBXDE(population[p1].indiv, population[p2].indiv, population[p3].indiv,population[p2].indiv,population[p1].indiv,child1,child2,child1);
		}

		// apply polynomial mutation
		// ����ʽ���죬nvarΪ���߱���������child1�Ĳ��־��߱�������
		realmutation(child1, 1.0/nvar);

		// evaluate the child solution
		// ����child1������Ŀ�꺯��
		child1.obj_eval();

		// ͨ������child1������ȺP�ʹ浵A�е���Ӧֵ
		update_population(child1);
	}
	changeIsTrue = false;
	delete [] perm;
}

void CDVC::StaticClassification()
{
	int i,j;
	int size = Archive.size();
			
	double ** objs = new double* [nobj];
	for(i = 0; i < nobj; i++)
		objs[i] = new double[size];
	double ** vars = new double* [nvar];
	double **   cc = new double* [nvar];

	for(i = 0; i < nvar; i++)
	{
		vars[i] = new double[size];
		cc[i]   = new double[nobj];
	}

	for(i = 0; i < size; i++)
	{
		for(j = 0; j < nobj; j++)
			objs[j][i] = Archive[i].y_obj[j];
		for(j = 0; j < nvar; j++)
			vars[j][i] = Archive[i].x_var[j];
	}

	for(i = 0; i < nvar; i++)
	{
		for(j = 0; j < nobj; j++)
		{
			cc[i][j] = xiangguanxishu(vars[i], objs[j], size);
		}
	}
	
	for(i = 0; i < nvar; i++)
	{
		vector < double > man_min;
		man_min = find_Max_Min(cc[i], nobj);
		if(man_min[0] - man_min[1] > beta)
			flagSBXDE[i] = 1;
		else
			flagSBXDE[i] = 0;
	}

	for (i = 0; i < nobj; i++)
	{
		delete[] objs[i];
	}
	for(i = 0; i < nvar; i++)
	{
		delete[] vars[i];
		delete[]   cc[i];
	}
	delete[] objs;
	delete[] vars;
	delete[] cc;
}
void CDVC::execute(int run)
{
	para_init();

	// �������
	seed = (seed + 23)%1377;
	rnd_uni_init = -(long)seed;

	// initialization 
	int gen   = 1;
	init_population();
	environmentselection();

	// evolution
	for(gen = 1; gen <= max_gen; gen++)
	{
		cout << gen << endl;
		itt=gen;		
		StaticClassification();
		introduce_dynamics(gen);
		evolution();
        environmentselection();
	}
	population.clear();
}

void CDVC::para_init()
{
	CES = 1.0E-300;
	Parar = 0;
	Tt = 0.0;
	for(int n = 0; n < nvar; n++) flagSBXDE[n] = 0;
}

void CDVC::introduce_dynamics(int gen)
{	
	int g = (gen - T0) > 0 ? (gen - T0) : 0;
	if (g > 0)
		Tt = 1.0 / nt*(floor(1.0*(g-1)/ taut) + 1);
	else
		Tt = 0.0;

	if ((Tt > 0) && (g%taut == 1))
		if (!strcmp(strTestInstance, "dMOP3"))
		{
			Parar = rand()%nvar;
		}
}

bool CDVC::detect_change(int n)
{
	// method 1: measure the difference between old objective values and new ones
	int i;
	vector <double> oldobj(nobj,0.0);
	for (i = 0; i < nobj; i++)
		oldobj[i] = population[n].indiv.y_obj[i];
	population[n].indiv.obj_eval();

	double Tolerror = CES;

	for (i = 0; i < nobj; i++)
	{
		if (fabs(population[n].indiv.y_obj[i] - oldobj[i])>Tolerror)
		{
			return true;
		}
	}
	return false;
}

void CDVC::react_change()
{
	//Ԥ��+ά��+����
	int size = population.size();
	int i,n;
	C1.resize(nvar, 0.0);

	for(n = 0; n < nvar; n++)
	{
		C1[n] = 0.0;
		for(i = 0; i < size; i++)
		{
			C1[n] += population[i].indiv.x_var[n];
		}
		C1[n] /= population.size();
	}

	vector < double > C;
	double result = 0.0;
	for(i = 0; i < nvar; i++)
	{
		result = myFilter[i].predict(C1[i]);
		C.push_back(result);
	}

	//ʵ����忪ʼ
	vector <CDVCInd> trial;
	CDVCInd data;
	for(i = 0;i < nvar; i++)
	{
		for(n = 0;n<nvar;n++)
		{
			if(i != n)
			{
				data.x_var[n]=C1[n];
			}
			else
			{
				if(C0.size())
				{
					data.x_var[n] = C[n];
					if (data.x_var[n]<lowBound[n]) data.x_var[n]=lowBound[n];
					if (data.x_var[n]>uppBound[n]) data.x_var[n]=uppBound[n];
					if (data.x_var[n]==C1[n])	   data.x_var[n]=lowBound[n]+rnd_uni(&rnd_uni_init)*(uppBound[n]-lowBound[n]);
				}
				else
				{
					data.x_var[n]=lowBound[n]+rnd_uni(&rnd_uni_init)*(uppBound[n]-lowBound[n]);
				}
			}
		}
		data.obj_eval();
		trial.push_back(data);
	}
	for(n=0;n<nvar;n++)
		data.x_var[n]=C1[n];
	data.obj_eval();
	int flagpredict[50];
	for(i=0;i<nvar;i++)
	{
		int flagco = trial[i].compare(data);
		if(flagco == -1)
			flagpredict[i] = 1;
		else
			flagpredict[i] = 0;
	}
	trial.push_back(data);

	Archive.clear();//��մ浵
	offspring.clear();//��������

	//����ttest
	if(C0.size())
	{	
		for(n = 0; n < nvar; n++)
		{
			LastDV[n] = CurrentDV[n];
			CurrentDV[n] = 0;
			for(i = 0; i < size; i++)
			{
				CurrentDV[n] += pow((population[i].indiv.x_var[n] - C1[n]),2)/(size - 1);
			}
		}
		for(n = 0; n < nvar; n++)
		{
			ttest[n]=(C1[n]-C0[n])/sqrt(LastDV[n]/size+CurrentDV[n]/size);
		}
	}
	else
	{
		for(n = 0; n < nvar; n++)
		{
			CurrentDV[n] = 0;
			for(i = 0; i < size; i++)
			{
				CurrentDV[n] += pow((population[i].indiv.x_var[n] - C1[n]),2)/(size - 1);
			}
		}
	}

	vector <int> accept, v2;
	
	int id0, id1, id2, tmp;
	for (i = 0; i < size; i++)
		v2.push_back(i);

	//��ֵ�㿪ʼ
	double min0, min1, min2;
	min0 = 1.0e+30, min1 = 1.0e+30, min2 = 1.0e+30;
	for (i = 0; i<size; i++)
	{
		if (min0 > population[i].indiv.y_obj[0]) 
		{
			id0 = i;
			min0 = population[i].indiv.y_obj[0];
		}
		if (min1 > population[i].indiv.y_obj[1])
		{
			id1 = i;
			min1 = population[i].indiv.y_obj[1];
		}
		if(nobj > 2)
		{
			if (min2 > population[i].indiv.y_obj[2])
			{
				id2 = i;
				min2 = population[i].indiv.y_obj[2];
			}
		}
	}

	tmp = v2[id0];
	accept.push_back(v2[id0]);
	v2[id0] = v2[size - accept.size()];
	v2[size - accept.size()] = tmp;

	if (id0 != id1)
	{
		tmp = v2[id1];
		accept.push_back(v2[id1]);
		v2[id1] = v2[size - accept.size()];
		v2[size - accept.size()] = tmp;
	}

	if(nobj > 2)
	{
		if (id0 != id2 && id1 != id2)
		{
			tmp = v2[id2];
			accept.push_back(v2[id2]);
			v2[id2] = v2[size - accept.size()];
			v2[size - accept.size()] = tmp;
		}
	}
	//��ֵ�����

	vector<int> reject,predict, mark(size, 1);

	double stepsize = 1.0;
	if (C0.size()) 
	{
		stepsize = dist_vector(C0, C1);
	}

	for (i = 0; i < accept.size(); i++)
	{
		mark[accept[i]] = 0;
		population[accept[i]].indiv.obj_eval();
		fill_union(population[accept[i]].indiv);
	}

	for (i = 0; i < size; i++)
	{
		if (mark[i])
		{
			reject.push_back(i);
			predict.push_back(i);
		}
	}
	int k = 0;
	for (i = 0; i < predict.size(); i++)
	{
		if(i >= predict.size()-nvar-1)//ʵ�����
		{
			for (n = 0; n < nvar; n++)
				population[predict[i]].indiv.x_var[n] = trial[k].x_var[n];
			for (n = 0; n < nobj; n++)
				population[predict[i]].indiv.y_obj[n] = trial[k].y_obj[n];
			
			fill_union(population[predict[i]].indiv);
			update_achive(population[predict[i]].indiv);
			k++;
		}
		else
		{
			if (C0.size())
			{
				for (int n = 0; n < nvar; n++)
				{
					if(fabs(ttest[n]) > alpha)
					{
						if(flagpredict[n] == 1)
						{
							population[predict[i]].indiv.x_var[n] += C[n] - C1[n];
						}
						else
						{
							population[predict[i]].indiv.x_var[n] += rnd_gaussian(&rnd_uni_init, 0, stepsize / sqrt(4 * nvar));
						}
					}
					if (population[predict[i]].indiv.x_var[n]<lowBound[n]) population[predict[i]].indiv.x_var[n]=lowBound[n];
					if (population[predict[i]].indiv.x_var[n]>uppBound[n]) population[predict[i]].indiv.x_var[n]=uppBound[n];
				}//for (int n = 0; n < nvar; n++)
			}//if (C0.size())
			else
			{
				realmutation(population[i].indiv, 2.0 / nvar, 4);
				//population[predict[i]].indiv.rnd_init(); // random reinitialization
			}
			
			population[predict[i]].indiv.obj_eval();
			fill_union(population[predict[i]].indiv);
			update_achive(population[predict[i]].indiv);
		}//if(i<predict.size()-nvar-1)
	}//for (i = 0; i < predict.size()-nvar-1; i++)

	C0.resize(nvar, 0.0);
	C0=C1;

	StaticClassification();
}
#endif