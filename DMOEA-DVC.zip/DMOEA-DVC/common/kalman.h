#ifndef _KALMAN_H_
#define _KALMAN_H_

#include "global.h"

using namespace std;

class KalmanFilter{
public:
	KalmanFilter();
	virtual ~KalmanFilter();

	double predict(double measurement);//measurement:zk
	vector < double > state;//xk
	vector < double > factor;//K
	vector < double > extraction;//H
	vector < vector < double > > update;//A
	vector < vector < double > > cov_error;//P
	vector < vector < double > > cov_process;//Q
	double cov_measure;
};

KalmanFilter::KalmanFilter()
{
	int order = kalman_order;
	state.resize(order, 0);

	update.resize(order, vector < double > (order, 0));
	int i, j;
	for(i = 0; i < order; i++)	
		for(j = 0; j < order; j++)
			if(i == j)
			{
				update[i][j]=1.0;
				if(j < kalman_order - 1)
					update[i][j+1] = 1.0;
			}

	cov_error.resize(order, vector< double >(order,0.0 ) );
	for(i = 0; i < order; i++)
		for(j = 0; j < order; j++)
			if(i == j)
				cov_error[i][j] = 1.0;

	extraction.resize(order, 0.0);
	extraction[0] = 1.0;

	cov_measure = var_measure;
	cov_process.resize(order, vector < double >(order, var_process));
	for(i = 0; i < order; i++)
		for(j = 0; j < order; j++)
			if(i != j)
				cov_process[i][j] = 0.0;
}

KalmanFilter::~KalmanFilter()
{
}

double KalmanFilter::predict(double measurement)
{
	int i, j, k;
	int order = kalman_order;

	factor.clear();
	factor.resize(order, 0.0);
	for(i = 0;i < order; i++)
		for(j = 0; j < order; j++)
			factor[i] += cov_error[i][j] * extraction[j] / (cov_error[0][0] + cov_measure);

	double y;
	y = measurement - state[0];
	for(i = 0; i < order; i++)
		state[i] = state[i] + factor[i] * y;

	vector < vector < double > > temp1(order, vector < double > (order, 0.0));
	for (i = 0; i < order; i++)
		for (j = 0; j < order; j++)
			if (i == j)
				temp1[i][j] = 1 - factor[i] * extraction[j];
			else
				temp1[i][j] = 0 - factor[i] * extraction[j];

	vector < vector < double > > temp2(order,vector < double > (order, 0.0));
	for (i = 0; i < order; i++)
		for(j = 0; j < order; j++ )
			for(k = 0; k < order; k++ )
				temp2[i][j] += temp1[i][k] * cov_error[k][j];

	cov_error = temp2;

	vector < double > temp3(order, 0.0);
	for(i = 0; i < order; i++)
		for(j = 0; j < order; j++)
			temp3[i] += update[i][j] * state[j];
	state = temp3;

	vector < vector < double > > temp4(order,vector < double > (order, 0.0));
	for (i = 0; i < order; i++)
		for(j = 0; j < order; j++)
			for(k = 0; k < order; k++ )
				temp4[i][j] += cov_error[i][k] * update[j][k];

	cov_error.clear();
	cov_error.resize(order,vector < double > (order, 0.0));
	for (i = 0; i < order; i++)
		for(j = 0; j < order; j++)
		{
			for(k = 0; k < order; k++ )
				cov_error[i][j] += update[i][k] * temp4[k][j];
			cov_error[i][j] += cov_process[i][j];
		}
	return state[0];
}
#endif
