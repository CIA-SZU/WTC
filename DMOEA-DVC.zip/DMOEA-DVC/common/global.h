#ifndef __GLOBAL_H_
#define __GLOBAL_H_

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <memory.h>
#include <vector>
#include "..\common\random.h"

using namespace std;

#define pi 3.141592653589793238462643383279502884197169399375105

//******** Parameters in test instance *********************************************
int     nvar,      //  the number of variables
		nobj;      //  the number of objectives

double lowBound[50],uppBound[50];

double  CES=1.0E-300;
char    strTestInstance[256];
// *********************************************************************************

//******** Parameters in random number *********************************************
int     seed    = 177;
long    rnd_uni_init;        
//**********************************************************************************

//******** Common parameters in MOEAs **********************************************
int		max_gen =300,     //  the maximal number of generations
		max_run = 5,      //  the maximal number of runs
		pops    = 100,    //  the population size
		nfes,			  //  the number of function evluations
		itt;              // iteration =gen;
//**********************************************************************************

//*******  Dynamic paramter configuration*******************************************
int  nt = 10,              // frequency
     taut = 10,            // severity
     T0=50;                // number of generations for original static optimization

int  Parar=0;              // unchanged index within a time window, 0 at the beginning

double Tt=0.0;             // real time steps

double scale[100];
vector <double> idealpoint;
vector <double> nadirpoint;
vector <double> intercept;

vector <double> normvector; // normal vector of the hyper-plane
char   strFunctionType[256], 
       strAlgorithmType[256]; 
//***************************************************************************************

//******** Parameters in SBX *******************************************************
int		etax    = 20,     
		etam    = 20;

double  realx, realm;    // probability in SBX crossover and polynomial mutation

int     gID;
//**********************************************************************************

//******** Parameters used in Kalman Filter for prediction *************************
double var_process = 0.04;
double var_measure = 0.01;
int kalman_order = 3;

int flagSBXDE[50];

string str_benchmark;
char parShort[100];

double alpha = 5.0;
double beta = 0.6;

#endif