#ifndef __CDVCCLASS_H_
#define __CDVCCLASS_H_

#include "DVCclass.h"
#include "..\common\global.h"
#include "..\common\recombination.h"
#include "..\common\common.h"
#include "..\common\kalman.h"
#include "..\common\matrix.h"

class CDVC
{

public:
	CDVC();
	virtual ~CDVC();
	void init_population();                       // initialize the population
	vector <int> rank_pop(vector <CDVCInd> &pop); // identify nondominated set
	void update_population(CDVCInd &indiv);       // update population 
	void update_achive(CDVCInd &ind);             // update archive
	void sbxevolution();                          // offspring generation and change response
	int  tour_selection();					      // Tournament selection of parents
	void environmentselection();
	void fill_union(CDVCInd &ind);
	vector  <int> truncation(vector <CDVCInd> pop, vector <int> v1, int m);
	vector<vector <int> > preservation(vector <CDVCInd> &pop, int m);
	void introduce_dynamics(int g);
	bool detect_change(int n);
	void react_change();
	void para_init();
	void execute(int run);
	vector <CFIN>      population;
	vector <CDVCInd>   ps;
	vector <CDVCInd>   offspring;
	vector <int>       array;
	CDVCInd           *ind_arr;

	vector <CDVCInd>   Archive;
	int                nondomsize;

	vector<double>  C0, C1;             // Store centriod of PS in the past two PSs

	int                 popsize;
	void operator=(const CDVC &moea);

	vector < KalmanFilter > myFilter;
	double ttest[50];
	double LastDV[50];
	double CurrentDV[50];

	void ClassificationSO();

	void save_front(char savefilename[1024]); // save the pareto front into files
	void save_ps(char savefilename[1024]);
	void save_Archive(char saveFilename[1024]);
	void save_ArchivePS(char saveFilename[1024]);
	void save_dis(char savefilename[1024]);

	vector<double> igd;
	vector<double> gd;
	vector<double> ms;
	void load_new_PF();
	void calc_igd();
	void calc_ms();
	void calc_gd();
	void save_ALL(char saveFilename[1024]);
	void save_ALL(string saveFilename);
	int n_change;
	vector<CDVCInd>   pf;
};

CDVC::CDVC()
{
	int n;
	ind_arr = new CDVCInd[nobj];
	myFilter.resize(nvar);
	// initialize ideal point
	for(n = 0; n < nobj; n++)
	{
		idealpoint.push_back(1.0e+30);
		nadirpoint.push_back(-1.0e+30);
		intercept.push_back(-1.0e+30);
		ind_arr[n].rnd_init();
		ind_arr[n].obj_eval();
	}
}

CDVC::~CDVC()
{
	idealpoint.clear();
	nadirpoint.clear();
	intercept.clear();
	delete [] ind_arr;
}

void CDVC::init_population()
{
	int i;
	for(i = 0; i < pops; i++)
	{	
		CFIN sub;
		population.push_back(sub);
		population[i].indiv.rnd_init();
		population[i].indiv.obj_eval();
	}	
}

void CDVC::operator=(const CDVC &alg)
{

	population = alg.population;
	ps         = alg.ps;
	ind_arr    = alg.ind_arr;
	offspring  = alg.offspring;
	popsize    = alg.popsize;
}

void CDVC::update_population(CDVCInd &indiv)
{
	int k = 0, incomp = 0;
	int i;
	double max = -1.0e+30;
	indiv.ncount = 0;
	for(i = 0; i < pops; i++)
	{
		int dominate = population[i].indiv.compare(indiv);
		switch(dominate)
		{
			case 2: return;
				break;
			case 1: population[i].indiv.ncount++; 
				break;
			case 0: incomp++;
				break;
			case -1: indiv.ncount++;
				break;
			default: break;
		}
		if(max < population[i].indiv.ncount)
		{
			k = i;
			max = population[i].indiv.ncount;
		}
	}

	// do nothing if indiv is worse than any ind in pop
	if(max < indiv.ncount) return;

	// replace a random ind with indiv if indiv and pop are nondominated
	if(incomp == pops)
		k = int(pops*rnd_uni(&rnd_uni_init));

	indiv.fitness = 1.0 * indiv.ncount;
	population[k].indiv = indiv;
	// update archive
	if(indiv.ncount < 1) update_achive(indiv);
}

void CDVC::update_achive(CDVCInd &ind)
{
	int i;
	int size = Archive.size();
	for(i = 0; i < size; i++)
	{
		int dominate = Archive[i].compare(ind);
		if(dominate == 2 || dominate == -1) break;
		if(dominate = 1)
		{
			Archive.erase(Archive.begin() + i); 
			size--;
		}
	}
	Archive.push_back(ind);
}

int CDVC::tour_selection()
{
	int p1 = int(rnd_uni(&rnd_uni_init)*pops);
	int p2 = int(rnd_uni(&rnd_uni_init)*pops);

	if(population[p1].indiv.ncount < population[p2].indiv.ncount)
		return p1;
	else
		return p2;
}

vector <int> CDVC::rank_pop(vector <CDVCInd> &pop)
{
	int i, j;
	// rank: only identify nondominated solutions in the population (0==nondominated)
	vector <int> nondom;
	for(i = 0; i < pop.size(); i++)
		pop[i].rank = 0;
	int dominated;
	for(i = 0; i < pop.size(); i++)
	{
		for(j = 0; j < pop.size(); j++)
		{
			dominated = pop[j].compare(pop[i]);
			if(dominated == -1) pop[i].rank++;
		}
	}
	for(i = 0; i < pop.size(); i++) 
	{
		if(pop[i].rank < 1) 
			nondom.push_back(i);
	}
	return nondom;
}

void CDVC::environmentselection()
{
	// merge of current population and archive population
	// duplicate individuals are removed.
	int i;
	for(i = 0; i < pops; i++)
		fill_union(population[i].indiv);

	// identification of nondominated solutions
	Archive.clear();
	vector< vector< int > > Index;
	Index = preservation(offspring, pops);
	vector< int > eliteIn(Index[0]);
	vector< int > nondomIn(Index[1]);
	nondomsize = nondomIn.size();

	if(nondomsize < pops)
	{
		for(i = 0; i < nondomsize; i++)
			Archive.push_back(offspring[nondomIn[i]]);
		for(i = 0; i < pops; i++)
			population[i].indiv = offspring[eliteIn[i]];
	}

	if(nondomsize == pops)
	{
		for(i = 0; i < pops; i++)
		{
			population[i].indiv=offspring[nondomIn[i]];
			Archive.push_back(offspring[nondomIn[i]]);
		}
	}

	if(nondomsize > pops)
	{
		// Reduce the risk of too many extreme solutions.
		vector < int > trunIn;
		trunIn = truncation(offspring, nondomIn, pops);
		for(i = 0; i < pops; i++)
		{
			population[i].indiv = offspring[trunIn[i]];
			Archive.push_back(offspring[trunIn[i]]);
		}
	}
	offspring.resize(pops);
	for(i = 0; i < pops; i++)
		offspring[i] = population[i].indiv;
	while(offspring.size() > pops) offspring.pop_back();
}

vector <vector <int> > CDVC::preservation(vector <CDVCInd> &pop, int m)
{
	int i, j;
	int pop_size = pop.size();
	double *fit = new double[pop_size];
	int* idx2 = new int[pop_size];
	vector < int > accept, reject;
	int id = 0;
	for(i = 0; i < pop_size; i++)
	{
		pop[i].ncount = 0;
		double temp_ncount = 0;
		for(j = 0; j < pop_size; j++)
		{
			if(i != j)
			{
				int dominate = pop[i].compare(pop[j]);
				if(dominate == 1)  temp_ncount++;
			}
		}
		pop[i].ncount = temp_ncount;
	}
	// nondominance identification
	vector < int > nondomindex;
	for(i = 0; i < pop_size; i++)
	{
		if(pop[i].ncount == 0)
		{
			nondomindex.push_back(i);
		}
		pop[i].fitness = 1.0 * (pop[i].ncount);
		fit[i] = pop[i].fitness;
		idx2[i] = i;
	}
	
	minfastsort(fit, idx2, pop_size, m);
	for(i = 0; i < pop_size; i++)
	{
		if(i < m) accept.push_back(idx2[i]);	
	}
	delete [] fit;
	delete [] idx2;
	vector < vector < int > > twovector;
	twovector.push_back(accept);
	twovector.push_back(nondomindex);
	return twovector;
}

vector < int > CDVC::truncation(vector < CDVCInd > pop, vector < int > v1, int m)
{
	int size = v1.size();
	int i, j, k;
	int **distIndex = new int*[size];
	double **distSort = new double*[size];
	int pop_size = pop.size();
	double **objs = new double*[pop_size];	
	for(i = 0; i < pop_size; i++)
	{
		objs[i] = new double [nobj];
		for(j = 0; j < nobj; j++)
			objs[i][j] = pop[i].y_obj[j];
	}
	int *record = new int [size];
	vector <int> accept;
	double INF = 1.0E+30;
	for(i = 0; i < size; i++)
	{
		record[i] = 1;
		distIndex[i] = new int[size];
		distSort[i] = new double[size];
		for(j = 0; j < i; j++)
		{
			distIndex[i][j] = j;
			double temp = 0.0;
			for(k = 0; k < nobj; k++)
				temp += (objs[v1[i]][k]-objs[v1[j]][k])*(objs[v1[i]][k]-objs[v1[j]][k]);
			distSort[i][j] = sqrt(temp);
			distIndex[j][i] = i;
			distSort[j][i] = distSort[i][j];
		}
		distIndex[i][i] = i;
		distSort[i][i] = INF;
	}
	for(i = 0; i < size; i++)
	{
		minquicksort(distSort[i], distIndex[i], 0, size - 1);
	}
		
	int cursize = size, mark, count;
	double min;
	bool same;
	while(cursize > m)
	{
		min = INF;
		for(i = 0; i < size; i++)
			if(record[i])
			{
				if(min>distSort[i][0])
				{
					min = distSort[i][0];
					mark = i;
				}
				else
				{
					if(min == distSort[i][0])
					{
						same = (pop[v1[i]].y_obj==pop[v1[mark]].y_obj);
						if(same == false)
						{
							count = 0;
							while(distSort[mark][count] == distSort[i][count] && count < cursize - 1) count++;
							if(distSort[mark][count] > distSort[i][count]) mark = i;
						}
					}
				}
			}
		record[mark] = 0;
		for(i = 0; i < size; i++)
		{
			int flag = 0;
			if(record[i])
			{
				for(j = 0; j < cursize; j++)
				{
					if(distIndex[i][j] == mark) flag = 1;
					if(flag)
						if(j < cursize - 1)
						{
							distSort[i][j] = distSort[i][j + 1];
							distIndex[i][j] = distIndex[i][j + 1];
						}
				}
				distSort[i][cursize - 1] = INF;
				distIndex[i][cursize - 1] = mark;
			}
		}
		cursize--;
	}
	for(i = 0; i < size; i++)
	{
		if(record[i]) accept.push_back(v1[i]);
		delete[] distSort[i];
		delete[] distIndex[i];
	}
	delete[] distSort;
	delete[] distIndex;
	delete record;
	for(i = 0; i < pop_size; i++)
		delete[] objs[i];
	delete[] objs;
	return accept;
}

void CDVC::fill_union(CDVCInd &ind)
{
	int i;
	bool flag = true;
	int  size = offspring.size();
	for(i = 0; i < size; i++)
	{
		if(ind==offspring[i])
		{
			flag = false;
			break;
		}
	}
	if(flag) offspring.push_back(ind);
}

void CDVC::sbxevolution()
{
	int *perm = new int[pops];
	random_permutation(perm, pops);
	int i, n;
	bool changeIsTrue = false, reactIsTrue=false;
	
	for(i = 0; i<pops; i++)
	{
		n = perm[i];
		if(!changeIsTrue && i < det)
			changeIsTrue = detect_change(n);
		if((!reactIsTrue)&&changeIsTrue)
		{
			react_change();
			reactIsTrue=true;
		}		
		// select the indexes of mating parents
		CDVCInd child1, child2;
		int dominate;
		int p1, p2, p3;
		p1= (int)(Archive.size())*rnd_uni(&rnd_uni_init);
		while(1)
		{
			p2 = tour_selection();  
			dominate = population[p2].indiv.compare(Archive[p1]);
			if(dominate != 2) break; 
		}
		while(1)
		{
			p3 = tour_selection();
			dominate = Archive[p1].compare(population[p3].indiv);
			if(dominate != 2 && p3 != p2) break;
		}		
		coevo(Archive[p1],population[p2].indiv,population[p3].indiv,population[p2].indiv,Archive[p1],child1,child2,child1);

		realmutation(child1, 1.0/nvar);
		child1.obj_eval();
		update_population(child1);
	}
	changeIsTrue = false;
	delete [] perm;
}

void CDVC::ClassificationSO()
{	
	int i, j, k;
	int size = population.size();
	double **rankx = new double* [nvar];
	double **ranky = new double* [nobj];

	double ** objs = new double* [size];
	double ** vars = new double* [size];
	for(i = 0; i < size; i++)
	{
		objs[i] = new double[nobj];
		vars[i] = new double[nvar];
	}

	for(k = 0; k < nvar; k++)
	{
		rankx[k] = new double [size];
		for(i = 0; i < size; i++)
		{
			rankx[k][i] = size;
			vars[i][k] = population[i].indiv.x_var[k];
		}
	}
	for(k = 0; k < nobj; k++)
	{
		ranky[k] = new double [size];
		for(i = 0; i < size; i++)
		{
			ranky[k][i] = size;
			objs[i][k] = population[i].indiv.y_obj[k];
		}
	}
	
	for(i = 0; i < size; i++)
	{
		for(j = i + 1; j < size; j++)
		{
			for(k = 0; k < nvar; k++)
			{
				if(vars[i][k] == vars[j][k])
					rankx[k][i] -= 0.5, rankx[k][j] -= 0.5;
				else if(vars[i][k] < vars[j][k])
					rankx[k][j]--;
				else
					rankx[k][i]--;
			}
			for(k = 0; k < nobj; k++)
			{
				if(objs[i][k] == objs[j][k])
					ranky[k][i] -= 0.5, ranky[k][j] -= 0.5;
				else if(objs[i][k] < objs[j][k])
					ranky[k][j]--;
				else
					ranky[k][i]--;
			}
		}
	}
//	cout << itt << "	";
	for(i = 0; i < nvar; i++)
	{
		double min = +1.0e+30;
		double max = -1.0e+30;
		for(j = 0; j < nobj; j++)
		{
			double temp = spearman(rankx[i],ranky[j],size);
			if(temp < min) min = temp;
			if(temp > max) max = temp;
		}
		//printf("%.2lf ", max);
		if(max > beta * 0.5 && min < -beta * 0.5)
			flagcoevo[i] = 1;
		else
			flagcoevo[i] = 0;
	}
	/*cout << itt << "	";
	for(i = 0; i < nvar; i++)
		cout << flagcoevo[i] << " ";*/
	//cout << endl;
	for(i = 0; i < nvar; i++)
	{
		delete[] rankx[i];
	}
	for(i = 0; i < nobj; i++)
	{
		delete[] ranky[i];
	}
	delete[] rankx;
	delete[] ranky;
	for(i = 0; i < size; i++)
	{
		delete[] vars[i];
		delete[] objs[i];
	}
	delete[] objs;
	delete[] vars;
}
void CDVC::execute(int run)
{
	para_init();

	seed = (seed + 23)%1377;
	rnd_uni_init = -(long)seed;

	// initialization 
	int gen   = 0;
	itt       = 0;
	nfes      = 0;

	init_population();
	environmentselection();

	// evolution
	for(gen = 1; gen <= max_gen; gen++)
	{
		itt = gen;		
		ClassificationSO();
		introduce_dynamics(gen);
		sbxevolution();
        environmentselection();
	}

	population.clear();
}

void CDVC::para_init()
{
	Parar = 0;
	Tt = 0.0;
	for(int n = 0; n < nvar; n++) flagcoevo[n] = 0;
}

void CDVC::introduce_dynamics(int gen)
{	
	int g = (gen - T0) > 0 ? (gen - T0) : 0;
	if(g > 0)
		Tt = 1.0 / nt*(floor(1.0*(g-1)/ taut) + 1);
	else
		Tt = 0.0;

	if((Tt > 0) && (g%taut == 1))
		if(!strcmp(strTestInstance, "dMOP3"))
		{
			Parar = rand()%nvar;
		}
}

bool CDVC::detect_change(int n)
{
// method 1: measure the difference between old objective values and new ones
	int i;
	vector <double> oldobj(nobj);
	for(i = 0; i < nobj; i++)
		oldobj[i] = population[n].indiv.y_obj[i];
	population[n].indiv.obj_eval();
	nfes--;

	double Tolerror = CES;

	for(i = 0; i < nobj; i++)
	{
		if(population[n].indiv.y_obj[i] != oldobj[i])
		{
			return true;
		}
	}
	return false;
}

void CDVC::react_change()
{
	int size = population.size();
	int i,n;
	C1.resize(nvar, 0.0);

	for(n = 0; n < nvar; n++)
	{
		C1[n] = 0.0;
		for(i = 0; i < size; i++)
			C1[n] += population[i].indiv.x_var[n];
		C1[n] /= size;
	}
	vector < double > C(nvar);
	for(i = 0; i < nvar; i++)
		C[i] = myFilter[i].predict(C1[i]);
	
	//classification in change response
	vector <CDVCInd> trial;
	CDVCInd data;
	for(i=0;i<nvar;i++)
	{
		for(n=0;n<nvar;n++)
		{
			if(i!=n)
			{
				data.x_var[n]=C1[n];
			}
			else
			{
				if(C0.size())
				{
					data.x_var[n] = C[n];
					if(data.x_var[n]<lowBound[n]) data.x_var[n]=lowBound[n];
					if(data.x_var[n]>uppBound[n]) data.x_var[n]=uppBound[n];
					if(data.x_var[n]==C1[n])	  data.x_var[n]=lowBound[n]+rnd_uni(&rnd_uni_init)*(uppBound[n]-lowBound[n]);
				}
				else
				{
					data.x_var[n]=lowBound[n]+rnd_uni(&rnd_uni_init)*(uppBound[n]-lowBound[n]);
				}
			}
		}
		data.obj_eval();
		trial.push_back(data);
	}
	for(n=0;n<nvar;n++)
		data.x_var[n]=C1[n];
	data.obj_eval();
	int flagpredict[50];
	for(i=0;i<nvar;i++)
	{
		int flagco = trial[i].compare(data);
		if(flagco == -1)
			flagpredict[i] = 1;
		else
			flagpredict[i] = 0;
	}
	trial.push_back(data);

	Archive.clear();
	offspring.clear();

	//compute ttest
	if(C0.size())
	{	
		for(n = 0; n < nvar; n++)
		{
			LastDV[n] = CurrentDV[n];
			CurrentDV[n] = 0.0;
			for(i = 0; i < size; i++)
			{
				CurrentDV[n] += pow((population[i].indiv.x_var[n] - C1[n]),2)/(size - 1.0);
			}
		}
		for(n = 0; n < nvar; n++)
		{
			ttest[n]=(C1[n]-C0[n])/sqrt(LastDV[n]/size+CurrentDV[n]/size);
		}
	}
	else
	{
		for(n = 0; n < nvar; n++)
		{
			CurrentDV[n] = 0.0;
			for(i = 0; i < size; i++)
			{
				CurrentDV[n] += pow((population[i].indiv.x_var[n] - C1[n]),2)/(size - 1.0);
			}
		}
	}

	vector <int> accept, v2;
	
	int id0, id1, id2, tmp;
	v2.resize(size);
	for(i = 0; i < size; i++) v2[i] = i;

	//boundary points
	double min0, min1, min2;
	min0 = 1.0e+30, min1 = 1.0e+30, min2 = 1.0e+30;
	for(i = 0; i<size; i++)
	{
		if(min0 > population[i].indiv.y_obj[0])
			id0 = i, min0 = population[i].indiv.y_obj[0];
		if(min1 > population[i].indiv.y_obj[1])
			id1 = i, min1 = population[i].indiv.y_obj[1];
		if(nobj > 2)
			if(min2 > population[i].indiv.y_obj[2])
				id2 = i, min2 = population[i].indiv.y_obj[2];
	}
	tmp = v2[id0];
	accept.push_back(v2[id0]);
	v2[id0] = v2[size - accept.size()];
	v2[size - accept.size()] = tmp;
	if(id0 != id1)
	{
		tmp = v2[id1];
		accept.push_back(v2[id1]);
		v2[id1] = v2[size - accept.size()];
		v2[size - accept.size()] = tmp;
	}
	if(nobj > 2)
		if(id0 != id2 && id1 != id2)
		{
			tmp = v2[id2];
			accept.push_back(v2[id2]);
			v2[id2] = v2[size - accept.size()];
			v2[size - accept.size()] = tmp;
		}

	vector<int> reject,predict, mark(size, 1);

	double stepsize;
	if(C0.size()) 
		stepsize = dist_vector(C0, C1);

	for(i = 0; i < accept.size(); i++)
	{
		mark[accept[i]] = 0;
		population[accept[i]].indiv.obj_eval();
		fill_union(population[accept[i]].indiv);
	}

	for(i = 0; i < size; i++)
	{
		if(mark[i])
		{
			reject.push_back(i);
			predict.push_back(i); // obtain indices of members to be predicted
		}
	}
	vector <int> vnondom;
	vnondom = rank_pop(offspring);
	for(i = 0; i < vnondom.size(); i++)
		Archive.push_back(offspring[vnondom[i]]);
	int k = 0;
	for(i = 0; i < predict.size(); i++)
	{
		if(i>=predict.size()-nvar-1)
		{
			for(n = 0; n < nvar; n++)
				population[predict[i]].indiv.x_var[n] = trial[k].x_var[n];
			for(n = 0; n < nobj; n++)
				population[predict[i]].indiv.y_obj[n] = trial[k].y_obj[n];
			
			fill_union(population[predict[i]].indiv);
			update_achive(population[predict[i]].indiv);
			k++;
		}
		else
		{
			if(C0.size())
			{
				for(n = 0; n < nvar; n++)
				{
					double temp = population[predict[i]].indiv.x_var[n];
					if(fabs(ttest[n]) > alpha)
					{
						
						if(flagpredict[n] == 1)
						{
							population[predict[i]].indiv.x_var[n] += C[n] - C1[n];
						}
						else
						{
							population[predict[i]].indiv.x_var[n]= lowBound[n]
								+ rnd_uni(&rnd_uni_init)*(uppBound[n]-lowBound[n]);
						}
					}
					if(population[predict[i]].indiv.x_var[n]<lowBound[n])
					{
						population[predict[i]].indiv.x_var[n]
							=lowBound[n]+rnd_uni(&rnd_uni_init)*(temp-lowBound[n]);
					}

					if(population[predict[i]].indiv.x_var[n]>uppBound[n])
					{
						population[predict[i]].indiv.x_var[n]
							=uppBound[n]-rnd_uni(&rnd_uni_init)*(uppBound[n]-temp);
					}
				}//for(int n = 0; n < nvar; n++)
			}//if(C0.size())
			else
			{
				realmutation(population[i].indiv, 2.0 / nvar, 4);
			}
			
			population[predict[i]].indiv.obj_eval();
			fill_union(population[predict[i]].indiv);
			update_achive(population[predict[i]].indiv);
		}//if(i<predict.size()-nvar-1)
	}//for(i = 0; i < predict.size()-nvar-1; i++)

	C0=C1;
	ClassificationSO();
}

void CDVC::save_front(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	int n, k;
	for(n = 0; n < pops; n++)
	{
		for(k = 0; k < nobj; k++)
			fout<<population[n].indiv.y_obj[k]<<"	";
		fout<<"\n";
	}
	fout.close();
}

void CDVC::save_Archive(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	int n, k;
	for(n = 0; n < Archive.size(); n++)
	{
		for(k = 0; k < nobj; k++)
			fout << Archive[n].y_obj[k] << "	";
		fout << "\n";
	}
	fout.close();
}

void CDVC::save_ps(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	int n, k;
	for(n = 0; n < pops; n++)
	{
		for(k = 0; k < nvar; k++)
			fout << population[n].indiv.x_var[k] << "	";
		fout << "\n";
	}
	fout.close();
}

void CDVC::save_ArchivePS(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	int n, k;
	for(n = 0; n < Archive.size(); n++)
	{
		for(k = 0; k < nvar; k++)
			fout << Archive[n].x_var[k] << "	";
		fout << "\n";
	}
	fout.close();
}

void CDVC::load_new_PF()
{
	pf.clear();
	char str1[50];
	sprintf(str1, "C:\\Users\\YC2Z\\Desktop\\POF\\");
	string str2 = "\\";
	string str3 = ".txt";
	char str[10];
	int g = (itt - T0)>0 ? (itt - T0) : 0;
	int xx = (floor(1.0*(g - 1) / taut) + 1);
	sprintf(str, "%d", xx);
	string filename = str1 + str_benchmark + str2 + str + str3;
	char parName1[1024];
	sprintf(parName1, filename.c_str());
	loadpfront(parName1, pf);
}

void CDVC::save_ALL(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	int k;
	for(k = 0; k<igd.size(); k++)
	{
		fout << k + 1 << "	" << igd[k] << "	" << gd[k] << "	" << ms[k] << endl;
	}
	fout.close();
}

void CDVC::save_ALL(string saveFilename)
{
	std::fstream fout;
	fout.open(saveFilename.c_str(), std::ios::out);
	int k;
	for(k = 0; k<igd.size(); k++)
	{
		fout << k + 1 << "	" << igd[k] << "	" << gd[k] << "	" << ms[k] << endl;
	}
	fout.close();
}

void CDVC::calc_igd()
{
	int i, j;
	double distance = 0.0;
	int pf_size = pf.size();
	for(i = 0; i < pf_size; i++)
	{
		double min_d = 1.0e+10;
		for(j = 0; j < pops; j++)
		{
			double d = dist_vector(pf[i].y_obj, population[j].indiv.y_obj);
			if(d < min_d) min_d = d;
		}
		distance += min_d;
	}
	distance /= pf_size;
	igd.push_back(distance);
}

void CDVC::calc_gd()
{
	int i, j;
	double distance = 0.0;
	for(i = 0; i<population.size(); i++)
	{
		double min_d = 1.0e+10;
		for(j = 0; j<pf.size(); j++)
		{
			double d = dist_vector(pf[j].y_obj, population[i].indiv.y_obj);
			if(d<min_d) min_d = d;
		}
		distance += min_d;
	}
	distance /= population.size();
	gd.push_back(distance);
}

void CDVC::calc_ms()
{
	double spread = 0.0, s, F_max, F_min, f_max, f_min;
	int i, k;
	for(k = 0; k < nobj; k++)
	{
		s = 0.0;
		F_max = -1.0e+10;
		F_min = +1.0e+10;
		f_max = -1.0e+10;
		f_min = +1.0e+10;
		for(i = 0; i < pf.size(); i++)
		{
			F_max = pf[i].y_obj[k] > F_max ? pf[i].y_obj[k] : F_max;
			F_min = pf[i].y_obj[k] < F_min ? pf[i].y_obj[k] : F_min;
		}
		for(i = 0; i < pops; i++)
		{
			CDVCInd PF_i = population[i].indiv;
			f_max = PF_i.y_obj[k] > f_max ? PF_i.y_obj[k] : f_max;
			f_min = PF_i.y_obj[k] < f_min ? PF_i.y_obj[k] : f_min;
		}
		s = f_max < F_max ? f_max : F_max;
		s -= f_min > F_min ? f_min : F_min;
		s /= (F_max - F_min);
		spread += s*s;
	}
	spread = sqrt(spread / nobj);
	ms.push_back(spread);
}
#endif