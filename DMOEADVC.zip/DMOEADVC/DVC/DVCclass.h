#ifndef __CDVCInd_H_
#define __CDVCInd_H_

#include "..\common\global.h"
#include "..\common\objective.h"
class CDVCInd{
public:
	CDVCInd();
	virtual ~CDVCInd();

	vector <double> x_var;
	vector <double> y_obj;

	void   rnd_init();
	void   obj_eval();

    bool   operator<(const CDVCInd &ind2);
	bool   operator<<(const CDVCInd &ind2);
    bool   operator==(const CDVCInd &ind2);
    void   operator=(const CDVCInd &ind2);

	int compare(const CDVCInd &ind2);
	void show_objective();
	void show_variable();

	int    rank, ncount, rin;
	double fitness;
	vector <double> weight;     // weight vector

};

CDVCInd::CDVCInd()
{
	x_var.resize(nvar, 0.0);
	weight.resize(nobj, 0.0);
    y_obj.resize(nobj, 0.0);
	rank = 0;
	fitness=0;
	ncount=0;
}

CDVCInd::~CDVCInd()
{

}

void CDVCInd::rnd_init()
{
    for(int n=0;n<nvar;n++)
	{
        x_var[n] = lowBound[n] + rnd_uni(&rnd_uni_init)*(uppBound[n] - lowBound[n]); 
	}
}

void CDVCInd::obj_eval()
{
	nfes++;
	objective(x_var, y_obj);
}


void CDVCInd::show_objective()
{
    for(int n=0; n<nobj; n++)
		printf("%f ",y_obj[n]);
	printf("\n");
}

void CDVCInd::show_variable()
{
    for(int n=0; n<nvar; n++)
		printf("%f ",x_var[n]);
	printf("\n");
}

void CDVCInd::operator=(const CDVCInd &ind2)
{
    x_var = ind2.x_var;
	y_obj = ind2.y_obj;
	rank  = ind2.rank;
	fitness=ind2.fitness;
	weight =ind2.weight;
	ncount =ind2.ncount;
	rin    =ind2.rin;
}

bool CDVCInd::operator<(const CDVCInd &ind2)
{
	bool dominated = true;
    for(int n=0; n<nobj; n++)
	{
		if(ind2.y_obj[n]<y_obj[n]) return false;
	}
	if(ind2.y_obj==y_obj) return false;
	return dominated;
}


bool CDVCInd::operator<<(const CDVCInd &ind2)
{
	bool dominated = true;
    for(int n=0; n<nobj; n++)
	{
		if(ind2.y_obj[n]<y_obj[n]  - 0.0001) return false;
	}
	if(ind2.y_obj==y_obj) return false;
	return dominated;
}

bool CDVCInd::operator==(const CDVCInd &ind2)
{
	if(ind2.y_obj==y_obj) return true;
	else return false;
}

int CDVCInd::compare(const CDVCInd &ind2)
{
	// 2: equals ind2
	// 1: dominated by ind2;
	// 0: mutually nondominated;
	//-1: dominate ind2
	int less=0, more=0;
    for(int n=0; n<nobj; n++)
	{
		double a, b;
		a = ind2.y_obj[n];
		b = y_obj[n];
		if(a==b) continue;
		if(a<b) more++;
		if(a>b) less++;
		if(more>0 && less>0) return 0;
	}
	if(more>0 && less==0) return 1;
	if(less>0 && more==0) return -1;
	if(less==0 && more==0) return 2;
	return 0;
}
//��Ⱥ
class CFIN  
{
public:
	CFIN();
	virtual ~CFIN();

	void show();

	CDVCInd         indiv;     // best solution
	vector <int>    array;     // neighbourhood table
	vector <double> namda;     // weight vector
	vector <double> ptable;    // probability of selecting a neighbour
	vector <int>    table;     // associated member indices 

	int domc;                  // times dominated by others

	double          density, fitness;

    void  operator=(const CFIN &sub2);
};

CFIN::CFIN()
{
	domc=0;
}

CFIN::~CFIN(){
}

void CFIN::show()
{
   for(int n=0; n<namda.size(); n++){
       printf("%f ",namda[n]);
   }
   printf("\n");
}

void CFIN::operator=(const CFIN &sub2){
    indiv  = sub2.indiv;
    array  = sub2.array;
	table  = sub2.table;
	namda  = sub2.namda;
}

#endif