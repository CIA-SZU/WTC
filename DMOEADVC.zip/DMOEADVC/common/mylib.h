#ifndef __MYLIB_H_
#define __MYLIB_H_

void guasselimination(vector<double> &x, vector<vector<double> > &A, vector<double> &b)
{
	int N=A.size();
	for (int i=0; i<N; i++)
		A[i].push_back(b[i]);
	for (i=0; i<N-1; i++)
	{
		for (int j=i+1; j<N; j++)
		{
			double ratio=A[j][i]/A[i][i];
			for (int k=i+1; k<N+1; k++)
			{
				A[j][k]-=A[i][k]*ratio;
			}
		}
	}
	x.resize(N);
	x[N-1]=A[N-1][N]/A[N-1][N-1];
	for (i=N-2; i>=0; i--)
	{
		for (int j=i+1; j<N; j++)
		{
			A[i][N]-=A[i][j]*x[j];
		}
		x[i]=A[i][N]/A[i][i];
	}

}

int nchoosek(int n, int k)
{
	double factn,factn_k,factk,prod=1;
	for (int i=1;i<=n;i++)
	{
		prod=prod*i;
		if (i==k)
			factk=prod;
		if (i==n-k)
			factn_k=prod;
	}
	factn=prod;
	return factn/(factk*factn_k);
}

void minfastsort(double x[], int idx[], int n, int m)
{
    for(int i=0; i<m; i++)
	{
	    for(int j=i+1; j<n; j++)
			if(x[i]>x[j])
			{
			    double temp = x[i];
				x[i]        = x[j];
				x[j]        = temp;
				int id      = idx[i];
				idx[i]      = idx[j];
				idx[j]      = id;
			}
	}
}

void minquicksort(double x[], int idx[], int low, int up)
{
	if(low >= up)
		return;

	int right, left;
	right = low;
	left = up;
	double key, idkey;
	key = x[low];
	idkey = idx[low];	

	while(right < left)
	{
		while(right < left && x[left] >= key) left--;
		x[right] = x[left];
		idx[right] = idx[left];

		while(right < left && x[right] <= key) right++;
		x[left] = x[right];
		idx[left] = idx[right];
	}

	x[right] = key;
	idx[right] = idkey;
    
	minquicksort(x, idx, low, right - 1);
	minquicksort(x, idx, right + 1, up);
}

double dist_array(double vec1[], double vec2[], int dim)
{
    double sum = 0;
	for(int n=0; n<dim; n++)
	    sum+= (vec1[n] - vec2[n])*(vec1[n] - vec2[n]);
	return sqrt(sum);
}

double dist_vector(vector <double> &vec1, vector <double> &vec2)
{
	int dim = vec1.size();
    double sum = 0.0;
	for(int n=0; n<dim; n++)
	    sum+=(vec1[n] - vec2[n])*(vec1[n] - vec2[n]);
	return sqrt(sum);
}

double dist_vector(double *vec1, double *vec2, int dim)
{
    double sum = 0.0;
	for(int n=0; n<dim; n++)
	    sum+=(vec1[n] - vec2[n])*(vec1[n] - vec2[n]);
	return sqrt(sum);
}

double angl_vector(vector <double> &vec1, vector <double> &vec2, vector <double> &vec3)
{
	int dim = vec1.size();
    double sum1 = 0, sum2 = 0, sum3 = 0;
	double A;
	for(int n=0; n<dim; n++)
	{
	    sum1+=(vec1[n] - vec3[n])*(vec2[n] - vec3[n]);
		sum2+=(vec1[n] - vec3[n])*(vec1[n] - vec3[n]);
		sum3+=(vec2[n] - vec3[n])*(vec2[n] - vec3[n]);
	}
	sum2=sqrt(sum2);
	sum3=sqrt(sum3);
	A=acos(sum1/(sum2*sum3));
	return A;
}

double norm_vector(vector <double> &vec)
{
	int    dim = vec.size();
	double sum = 0;
	for(int i=0;i<dim;i++)
        sum = sum + vec[i]*vec[i];
    return sqrt(sum);
}

double sum_vector(vector<double>&vec)
{
	int dim = vec.size();
	double sum = 0;
	for(int i=0;i<dim;i++)
        sum = sum + vec[i];
    return sum;
}

// inner product
double prod_vector(vector <double>&vec1, vector <double>&vec2)
{
	int dim = vec1.size();
    double sum = 0;
	for(int i=0; i<dim; i++)
		sum+= vec1[i]*vec2[i];
	return sum;
}

double cos_vector(vector <double> &p1, vector <double> &p2)
{
	int dim = p1.size();
	double norm_p1, norm_p2;
	double sum=0.0;
	for (int i=0; i<dim; i++)
	{
		sum+=p1[i]*p2[i];
	}
	norm_p1=norm_vector(p1);
	norm_p2=norm_vector(p2);
	sum=sum/(norm_p2*norm_p1);
	return sum<1?sum:1;
}

double cos_vector(vector <double> &p1, vector <double> &p2, vector<double> &r)
{
	int dim = p1.size();
	vector <double> shift_p1, shift_p2;
	double norm_p1, norm_p2;
	double sum=0.0;
	for (int i=0; i<dim; i++)
	{
		shift_p1.push_back(p1[i]-r[i]);
		shift_p2.push_back(p2[i]-r[i]);

		sum+=shift_p1[i]*shift_p2[i];
	}
	norm_p1=norm_vector(shift_p1);
	norm_p2=norm_vector(shift_p2);
	sum=sum/(norm_p2*norm_p1);
	return sum;
	if (fabs(sum)>=1.0)
		return 0;
	else
		return sum>0? acos((sum)):fabs(acos(sum));
}

double spearman(double *x, double *y, int size)
{
	int i;
	double result = 0.0;
	for(i = 0; i < size; i++)
		result += (x[i] - y[i])*(x[i] - y[i]);
	result = 1.0-6.0*result/size/(size*size-1.0);
	
	return result;
}

vector < double > find_Max_Min(double *x, int size)
{
	int i;
	double max = -1e-30;
	double min = 1e+30;
	vector < double > result(2, 0.0);
	for(i = 0; i < size; i++)
	{
		if(max < x[i]) max = x[i];
		if(min > x[i]) min = x[i];
	}
	result[0] = max;
	result[1] = min;
	return result;
}

vector < double > find_Max_Min(vector < double > x)
{
	int i;
	double max = -1e-30;
	double min = 1e+30;
	vector < double > result(2, 0.0);
	for(i = 0; i < x.size(); i++)
	{
		if(max < x[i]) max = x[i];
		if(min > x[i]) min = x[i];
	}
	result[0] = max;
	result[1] = min;
	return result;
}
double AVERAGE(double *X, int length)
{
	double result = 0.0;
	int i;
	for(i = 0; i < length; i++) result += X[i];
	result /= length;
	return result;
}
double VAR(double *X, int length)
{
	int i;
	double result = 0.0;
	double ave = AVERAGE(X, length);
	for(i = 0; i < length; i++) result += (X[i] - ave) * (X[i] - ave);
	result /= length;
	return result;
}

double DistanceOfPointToLine(vector <double> point, vector <double> namda, vector <double> idea)
{
	double k,b;
	double length;
	k = namda[1]/namda[0];
	b = idea[1]-k*idea[0];
	length = fabs(point[0] * k - point[1] + b)/ sqrt(k*k + 1);
	return length;
}

double LP(double *X, int length, int P)
{
	double result = 0.0;
	int i;
	for(i = 0; i < length; i++) result += pow(X[i], P);
	result = pow(result, 1.0 / P);
	return result;
}

void set_bound_nvar_nobj_pops()
{
	int k;
	if (!strcmp(strTestInstance, "FDA1"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "FDA2"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "FDA3"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "FDA4"))
	{
		nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "FDA5"))
	{
		nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0; 
		return;
	}

	if (!strcmp(strTestInstance, "dMOP1"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "dMOP2"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		return;
	}
	
	if (!strcmp(strTestInstance, "dMOP3"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "DIMP1")) 
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "DIMP2"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -2.0, uppBound[k] = 2.0;
		return;
	}
	if (!strcmp(strTestInstance, "JY1")) //JY1
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "JY2")) //JY2
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "JY3")) //JY3
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "JY4")) //JY4
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "JY5")) //JY5
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "JY6")) //JY6
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "JY7")) //JY7
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "JY8")) //JY8
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "JY9")) //JY9
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj - 1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj - 1; k < nvar; k++)
			lowBound[k] = -3.0, uppBound[k] = 3.0;
		return;
	}

	if (!strcmp(strTestInstance, "DF1"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "DF2"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "DF3"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 2.0;
		return;
	}
	if (!strcmp(strTestInstance, "DF4"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = -2.0, uppBound[k] = 2.0;
		return;
	}
	if (!strcmp(strTestInstance, "DF5"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}
	if (!strcmp(strTestInstance, "DF6"))
	{
        nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
	}

	if (!strcmp(strTestInstance, "DF7"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 1.0, uppBound[k] = 4.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
        return;
	}
	if (!strcmp(strTestInstance, "DF8"))
	{
		nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
		return;
    }
	if (!strcmp(strTestInstance, "DF9"))
    {
        nobj = 2;
		pops = 100;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
        return;
    }
	if (!strcmp(strTestInstance, "DF10"))
    {
        nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
        return;
    }
	if (!strcmp(strTestInstance, "DF11"))
    {
        nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nvar; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
        return;
    }
	if (!strcmp(strTestInstance, "DF12"))
    {
		nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
        return;
    }
	if (!strcmp(strTestInstance, "DF13"))
    {
		nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
        return;
    }
    if (!strcmp(strTestInstance, "DF14"))
    {
		nobj = 3;
		pops = 105;
		nvar = 11;
		for (k = 0; k < nobj-1; k++)
			lowBound[k] = 0.0, uppBound[k] = 1.0;
		for (k = nobj-1; k < nvar; k++)
			lowBound[k] = -1.0, uppBound[k] = 1.0;
        return;
    }
	cout << "This problem does not exist." << endl;
	system("pause");
}
#endif
