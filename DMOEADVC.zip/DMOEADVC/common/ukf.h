#include "..\common\global.h"
#include "..\common\matrix.h"
vector < double > f(vector < double > x);
vector < double > h(vector < double > x);
vector < vector < double > > sigmas(vector < double > x, vector < vector < double > > P, double c);
void utf(vector < vector < double > > X,
		 vector < double > Wm, vector < double > Wc,
		 double n, vector < vector < double > > R,
		 vector < double > &y, vector < vector < double > > &Y,
		 vector < vector < double > > &P, vector < vector < double > > &Y1);
void uth(vector < vector < double > > X,
		 vector < double > Wm, vector < double > Wc,
		 double n, double R,
		 vector < double > &y, vector < vector < double > > &Y,
		 vector < vector < double > > &P, vector < vector < double > > &Y1);

vector < double > ukf(vector < double > &x, vector < vector < double > > &P,
		 vector < double > z, vector < vector < double > > Q,
		 double R)
{
	int i;
	double L = x.size();
	double m = z.size();
	double alpha = 0.5;                           //default, tunable
	double ki = 10.0;                                 //default, tunable
	double beta = 2.0;                               //default, tunable

	// UTת������
	double lambda = alpha*alpha*(L+ki)-L;            //scaling factor
	double c = L+lambda;                             //scaling factor
	vector < double > Wm(1 + 2 * L);                 //weights for means
	Wm[0] = lambda/c;
	for(i = 0; i < 2*L; i++) Wm[i+1] = 0.5/c;
	vector < double > Wc = Wm;
	Wc[0] = Wc[0]+(1.0-alpha*alpha+beta);            //weights for covariance
	c = sqrt(c);
	vector < vector < double > > X = sigmas(x,P,c);  //sigma points around x
	vector < double > x1, z1;
	vector < vector < double > > X1, P1, X2, Z1, P2, Z2;
	utf(X, Wm, Wc, L, Q, x1, X1, P1, X2);            //unscented transformation of process
	uth(X1,Wm, Wc, m, R, z1, Z1, P2, Z2);            //unscented transformation of measurments

	// �˲�����
	vector < vector < double > > P12;
	vector < vector < double > > tmp3(Wc.size(), vector < double >(Wc.size(), 0.0));
	for(i = 0; i < Wc.size(); i++)
	{
		tmp3[i][i] = Wc[i];
	}
	
	P12 = dot(dot(X2,tmp3),transpose(Z2));           //transformed cross-covariance
	vector < vector < double > > K = dot(P12,invMat(P2));
	
	x = x1+dot(K,(z-z1));                            //state update
	P = P1-dot(K,transpose(P12));                    //covariance update
	tmp3.clear();

	return f(x);
}

vector < vector < double > > sigmas(vector < double > x, vector < vector < double > > P, double c)
{
	int i, j;
	vector < vector < double > > X, A, Y;
	A = c * Cholesky(P, P);
	Y.resize(x.size(), vector < double > (x.size()));
	for(i = 0; i < x.size(); i++)
		for(j = 0; j < x.size(); j++)
			Y[j][i] = x[j];
	X.resize(x.size(), vector < double > (2 * x.size() + 1));
	for(i = 0; i < X.size(); i++)
	{
		X[i][0] = x[i];
		for(j = 0; j < x.size(); j++)
		{
			X[i][j + 1] = Y[i][j] + A[i][j];
			X[i][j + 1 + x.size()] = Y[i][j] - A[i][j];
		}
	}
	return X;
}

void utf(vector < vector < double > > X,
		 vector < double > Wm, vector < double > Wc,
		 double n, vector < vector < double > > R,
		 vector < double > &y, vector < vector < double > > &Y,
		 vector < vector < double > > &P, vector < vector < double > > &Y1)
{
	int i, j, k;
	double L = X[0].size();
	y.resize(n, 0.0);
	Y.resize(n, vector < double > (L, 0.0));
	vector < vector < double > > tmp1(L);
	vector < vector < double > > tmp2 = transpose(X);
	for(k = 0; k < L; k++)
	{
		tmp1[k] = f(tmp2[k]);
		y = y + Wm[k] * tmp1[k];
	}
	Y = transpose(tmp1);
	Y1.resize(n, vector < double > (L));
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < L; j++)
		{
			Y1[i][j] = Y[i][j] - y[i];
		}
	}
	vector < vector < double > > tmp3(Wc.size(), vector < double >(Wc.size(), 0.0));
	for(i = 0; i < Wc.size(); i++)
	{
		tmp3[i][i] = Wc[i];
	}
	P = dot(dot(Y1,tmp3),transpose(Y1))+R;
	tmp1.clear();
	tmp2.clear();
	tmp3.clear();
}

void uth(vector < vector < double > > X,
		 vector < double > Wm, vector < double > Wc,
		 double n, double R,
		 vector < double > &y, vector < vector < double > > &Y,
		 vector < vector < double > > &P, vector < vector < double > > &Y1)
{
	int i, j, k;
	double L = X[0].size();
	y.resize(n, 0.0);
	Y.resize(n, vector < double > (L, 0.0));
	vector < vector < double > > tmp1(L);
	vector < vector < double > > tmp2 = transpose(X);
	for(k = 0; k < L; k++)
	{		
		tmp1[k] = h(tmp2[k]);
		y = y + Wm[k] * tmp1[k];
	}
	Y = transpose(tmp1);
	Y1.resize(n, vector < double > (L));
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < L; j++)
		{
			Y1[i][j] = Y[i][j] - y[i];
		}
	}
	vector < vector < double > > tmp3(Wc.size(), vector < double >(Wc.size(), 0.0));
	for(i = 0; i < Wc.size(); i++)
	{
		tmp3[i][i] = Wc[i];
	}
	P = dot(dot(Y1,tmp3),transpose(Y1));
	for(i = 0; i < P.size(); i++)
		for(j = 0; j < P[i].size(); j++)
			P[i][j] += R;
	
	tmp1.clear();
	tmp2.clear();
	tmp3.clear();
}

vector < double > f(vector < double > x)
{
	int i, j;
	int size = nvar;
	double t = 1.0;
	vector < double > result(kalman_order * size);
	for(i = 0; i < size; i++)
	{
		for(j = 0; j < kalman_order - 1; j++)
			result[i + j * size] = x[i + j * size] + t * x[i + (j+1) * size];
		result[(kalman_order - 1) * size + i] = x[(kalman_order - 1) * size + i];
	}
	return result;
}

vector < double > h(vector < double > x)
{
	vector < double > result(nvar);
	int i;
	for(i = 0; i < nvar; i++)
		result[i] = x[i];
	return result;
}