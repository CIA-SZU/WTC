#include "common\global.h"
#include "DVC\DVCfunc.h"
#include <time.h>

int main()
{
	int run;
	char *ins[] = {
	//   0       1      2      3      4      5       6       7       8       9
		"FDA1" ,"FDA2","FDA3","FDA4","FDA5","dMOP1","dMOP2","dMOP3","DIMP1", "DIMP2",
	//   10      11     12     13     14     15      16      17      18      19
		"JY1"  ,"JY2" ,"JY3" ,"JY4" ,"JY5" ,"JY6"  ,"JY7"  ,"JY8"  ,"JY9"  , "DF1"  ,
	//   20      21     22     23     24     25      26      27      28      29
		"DF2"  ,"DF3" ,"DF4" ,"DF5" ,"DF6" ,"DF7"  ,"DF8"  ,"DF9"  ,"DF10", "DF11" ,
	//   30      31     32
		"DF12","DF13","DF14"};

	cout << "DMOEA-DVC" << endl;
	int i = 0;
	seed = 177;
	taut = 10;
	max_run = 1;

	//for(taut = 5; taut <= 20; taut=taut*2)
	{
		max_gen = T0 + 10 * nt*taut;
		//for(i = 0; i <= 33; i++)
		{
			strcpy(strTestInstance,ins[i]);
			set_bound_nvar_nobj_pops();
			str_benchmark = ins[i];
			for(run = 1; run <= max_run; run++) 
			{
				CDVC DVC;
				DVC.execute(run);
			}
		}
	}
	return 0;
}
